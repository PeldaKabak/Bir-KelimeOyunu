﻿namespace Bir_kelime_Bir_islem
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btnyenioyun = new System.Windows.Forms.Button();
            this.Btnharfgetir = new System.Windows.Forms.Button();
            this.Btnharf9 = new System.Windows.Forms.Button();
            this.Btnharf2 = new System.Windows.Forms.Button();
            this.Btnharf3 = new System.Windows.Forms.Button();
            this.Btnharf4 = new System.Windows.Forms.Button();
            this.Btnharf8 = new System.Windows.Forms.Button();
            this.Btnharf7 = new System.Windows.Forms.Button();
            this.Btnharf5 = new System.Windows.Forms.Button();
            this.Btnharf6 = new System.Windows.Forms.Button();
            this.Btnharf1 = new System.Windows.Forms.Button();
            this.Btnpuan = new System.Windows.Forms.Button();
            this.Txtkelime = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Lblgirilenkelime = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Btnkontrol = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Txtistenilenharf = new System.Windows.Forms.TextBox();
            this.Bulduklarınız = new System.Windows.Forms.ListBox();
            this.Lblpuan = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.IndianRed;
            this.groupBox1.Controls.Add(this.Btnyenioyun);
            this.groupBox1.Controls.Add(this.Btnharfgetir);
            this.groupBox1.Controls.Add(this.Btnharf9);
            this.groupBox1.Controls.Add(this.Btnharf2);
            this.groupBox1.Controls.Add(this.Btnharf3);
            this.groupBox1.Controls.Add(this.Btnharf4);
            this.groupBox1.Controls.Add(this.Btnharf8);
            this.groupBox1.Controls.Add(this.Btnharf7);
            this.groupBox1.Controls.Add(this.Btnharf5);
            this.groupBox1.Controls.Add(this.Btnharf6);
            this.groupBox1.Controls.Add(this.Btnharf1);
            this.groupBox1.Location = new System.Drawing.Point(12, 86);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(823, 163);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bir kelime";
            // 
            // Btnyenioyun
            // 
            this.Btnyenioyun.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnyenioyun.Location = new System.Drawing.Point(414, 126);
            this.Btnyenioyun.Name = "Btnyenioyun";
            this.Btnyenioyun.Size = new System.Drawing.Size(137, 31);
            this.Btnyenioyun.TabIndex = 9;
            this.Btnyenioyun.Text = "Yeni Oyun";
            this.Btnyenioyun.UseVisualStyleBackColor = true;
            this.Btnyenioyun.Click += new System.EventHandler(this.Btnyenioyun_Click);
            // 
            // Btnharfgetir
            // 
            this.Btnharfgetir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharfgetir.Location = new System.Drawing.Point(250, 126);
            this.Btnharfgetir.Name = "Btnharfgetir";
            this.Btnharfgetir.Size = new System.Drawing.Size(137, 31);
            this.Btnharfgetir.TabIndex = 7;
            this.Btnharfgetir.Text = "Harf Getir";
            this.Btnharfgetir.UseVisualStyleBackColor = true;
            this.Btnharfgetir.Click += new System.EventHandler(this.Btnharfgetir_Click);
            // 
            // Btnharf9
            // 
            this.Btnharf9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf9.Location = new System.Drawing.Point(725, 49);
            this.Btnharf9.Name = "Btnharf9";
            this.Btnharf9.Size = new System.Drawing.Size(67, 64);
            this.Btnharf9.TabIndex = 8;
            this.Btnharf9.UseVisualStyleBackColor = true;
            this.Btnharf9.Visible = false;
            // 
            // Btnharf2
            // 
            this.Btnharf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf2.Location = new System.Drawing.Point(102, 49);
            this.Btnharf2.Name = "Btnharf2";
            this.Btnharf2.Size = new System.Drawing.Size(67, 64);
            this.Btnharf2.TabIndex = 7;
            this.Btnharf2.UseVisualStyleBackColor = true;
            this.Btnharf2.Visible = false;
            // 
            // Btnharf3
            // 
            this.Btnharf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf3.Location = new System.Drawing.Point(193, 49);
            this.Btnharf3.Name = "Btnharf3";
            this.Btnharf3.Size = new System.Drawing.Size(67, 64);
            this.Btnharf3.TabIndex = 6;
            this.Btnharf3.UseVisualStyleBackColor = true;
            this.Btnharf3.Visible = false;
            // 
            // Btnharf4
            // 
            this.Btnharf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf4.Location = new System.Drawing.Point(280, 49);
            this.Btnharf4.Name = "Btnharf4";
            this.Btnharf4.Size = new System.Drawing.Size(67, 64);
            this.Btnharf4.TabIndex = 5;
            this.Btnharf4.UseVisualStyleBackColor = true;
            this.Btnharf4.Visible = false;
            // 
            // Btnharf8
            // 
            this.Btnharf8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf8.Location = new System.Drawing.Point(639, 49);
            this.Btnharf8.Name = "Btnharf8";
            this.Btnharf8.Size = new System.Drawing.Size(67, 64);
            this.Btnharf8.TabIndex = 4;
            this.Btnharf8.UseVisualStyleBackColor = true;
            this.Btnharf8.Visible = false;
            // 
            // Btnharf7
            // 
            this.Btnharf7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf7.Location = new System.Drawing.Point(553, 49);
            this.Btnharf7.Name = "Btnharf7";
            this.Btnharf7.Size = new System.Drawing.Size(67, 64);
            this.Btnharf7.TabIndex = 3;
            this.Btnharf7.UseVisualStyleBackColor = true;
            this.Btnharf7.Visible = false;
            // 
            // Btnharf5
            // 
            this.Btnharf5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf5.Location = new System.Drawing.Point(368, 49);
            this.Btnharf5.Name = "Btnharf5";
            this.Btnharf5.Size = new System.Drawing.Size(67, 64);
            this.Btnharf5.TabIndex = 2;
            this.Btnharf5.UseVisualStyleBackColor = true;
            this.Btnharf5.Visible = false;
            // 
            // Btnharf6
            // 
            this.Btnharf6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf6.Location = new System.Drawing.Point(458, 49);
            this.Btnharf6.Name = "Btnharf6";
            this.Btnharf6.Size = new System.Drawing.Size(67, 64);
            this.Btnharf6.TabIndex = 1;
            this.Btnharf6.UseVisualStyleBackColor = true;
            this.Btnharf6.Visible = false;
            // 
            // Btnharf1
            // 
            this.Btnharf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnharf1.Location = new System.Drawing.Point(16, 49);
            this.Btnharf1.Name = "Btnharf1";
            this.Btnharf1.Size = new System.Drawing.Size(67, 64);
            this.Btnharf1.TabIndex = 0;
            this.Btnharf1.UseVisualStyleBackColor = true;
            this.Btnharf1.Visible = false;
            // 
            // Btnpuan
            // 
            this.Btnpuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Btnpuan.Location = new System.Drawing.Point(37, 23);
            this.Btnpuan.Name = "Btnpuan";
            this.Btnpuan.Size = new System.Drawing.Size(137, 31);
            this.Btnpuan.TabIndex = 10;
            this.Btnpuan.Text = "Puan tablosu";
            this.Btnpuan.UseVisualStyleBackColor = true;
            // 
            // Txtkelime
            // 
            this.Txtkelime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Txtkelime.Location = new System.Drawing.Point(205, 279);
            this.Txtkelime.Name = "Txtkelime";
            this.Txtkelime.Size = new System.Drawing.Size(247, 30);
            this.Txtkelime.TabIndex = 11;
            this.Txtkelime.TextChanged += new System.EventHandler(this.Txtkelime_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(24, 284);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 22);
            this.label1.TabIndex = 12;
            this.label1.Text = "Kelimeyi giriniz:";
            // 
            // Lblgirilenkelime
            // 
            this.Lblgirilenkelime.AutoSize = true;
            this.Lblgirilenkelime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Lblgirilenkelime.Location = new System.Drawing.Point(482, 287);
            this.Lblgirilenkelime.Name = "Lblgirilenkelime";
            this.Lblgirilenkelime.Size = new System.Drawing.Size(87, 22);
            this.Lblgirilenkelime.TabIndex = 13;
            this.Lblgirilenkelime.Text = "-----------";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(959, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 22);
            this.label2.TabIndex = 14;
            this.label2.Text = "Buldugunuz kelimeler:";
            // 
            // Btnkontrol
            // 
            this.Btnkontrol.Location = new System.Drawing.Point(355, 333);
            this.Btnkontrol.Name = "Btnkontrol";
            this.Btnkontrol.Size = new System.Drawing.Size(214, 39);
            this.Btnkontrol.TabIndex = 16;
            this.Btnkontrol.Text = "Kontrol";
            this.Btnkontrol.UseVisualStyleBackColor = true;
            this.Btnkontrol.Click += new System.EventHandler(this.Btnkontrol_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(585, 284);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 22);
            this.label3.TabIndex = 17;
            this.label3.Text = "istediginiz harf:";
            // 
            // Txtistenilenharf
            // 
            this.Txtistenilenharf.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Txtistenilenharf.Location = new System.Drawing.Point(737, 279);
            this.Txtistenilenharf.Name = "Txtistenilenharf";
            this.Txtistenilenharf.Size = new System.Drawing.Size(104, 30);
            this.Txtistenilenharf.TabIndex = 18;
            // 
            // Bulduklarınız
            // 
            this.Bulduklarınız.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Bulduklarınız.FormattingEnabled = true;
            this.Bulduklarınız.ItemHeight = 22;
            this.Bulduklarınız.Location = new System.Drawing.Point(905, 101);
            this.Bulduklarınız.Name = "Bulduklarınız";
            this.Bulduklarınız.Size = new System.Drawing.Size(364, 268);
            this.Bulduklarınız.TabIndex = 19;
            // 
            // Lblpuan
            // 
            this.Lblpuan.AutoSize = true;
            this.Lblpuan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Lblpuan.Location = new System.Drawing.Point(216, 27);
            this.Lblpuan.Name = "Lblpuan";
            this.Lblpuan.Size = new System.Drawing.Size(87, 22);
            this.Lblpuan.TabIndex = 20;
            this.Lblpuan.Text = "-----------";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(1297, 450);
            this.Controls.Add(this.Lblpuan);
            this.Controls.Add(this.Bulduklarınız);
            this.Controls.Add(this.Txtistenilenharf);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Btnkontrol);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Lblgirilenkelime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Txtkelime);
            this.Controls.Add(this.Btnpuan);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "BİR KELİME BİR İSLEM";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btnyenioyun;
        private System.Windows.Forms.Button Btnharfgetir;
        private System.Windows.Forms.Button Btnharf9;
        private System.Windows.Forms.Button Btnharf2;
        private System.Windows.Forms.Button Btnharf3;
        private System.Windows.Forms.Button Btnharf4;
        private System.Windows.Forms.Button Btnharf8;
        private System.Windows.Forms.Button Btnharf7;
        private System.Windows.Forms.Button Btnharf5;
        private System.Windows.Forms.Button Btnharf6;
        private System.Windows.Forms.Button Btnharf1;
        private System.Windows.Forms.Button Btnpuan;
        private System.Windows.Forms.TextBox Txtkelime;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Lblgirilenkelime;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btnkontrol;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Txtistenilenharf;
        private System.Windows.Forms.ListBox Bulduklarınız;
        private System.Windows.Forms.Label Lblpuan;
    }
}

